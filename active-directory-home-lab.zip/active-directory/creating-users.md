# Creating Users in Active Directory

## Steps
1. Open ADUC
2. Navigate to Users OU
3. Right click > New > User
4. Enter details
5. Set password
6. Enable account

## Result
User successfully created in domain.
