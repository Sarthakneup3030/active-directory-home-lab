# Domain Join Troubleshooting

## Issue
Windows client cannot join domain

## Checks
- DNS pointing to domain controller
- Network connectivity
- Correct domain name

## Fix
Updated DNS settings and re-attempted join
Result: Successful
