# Active Directory Home Lab

## Overview
This repo documents my Active Directory home lab built using Windows Server.

## Skills
- Active Directory Users & Groups
- Password resets & account unlocks
- Group Policy basics
- Domain setup
- Windows Server administration
