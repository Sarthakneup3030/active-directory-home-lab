# Password Policy (Group Policy)

## Steps
1. Open Group Policy Management
2. Edit Default Domain Policy
3. Navigate to:
   Computer Configuration > Policies > Windows Settings > Security Settings
4. Set password complexity and length
5. Run gpupdate /force
