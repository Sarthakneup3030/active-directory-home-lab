# Windows Server Setup

## Steps
1. Create VM
2. Install Windows Server 2022
3. Configure static IP
4. Install AD DS role
5. Promote to Domain Controller (lab.local)
